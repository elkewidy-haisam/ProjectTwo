package com.positivity.dao;


import com.positivity.model.*;


public interface UserRoleDAO {
	
	public UserRole getRoleByID(int user_role_id);

}

package controllertests;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.springframework.test.web.servlet.MockMvc;
import  static org.springframework.test.web.servlet.setup.MockMvcBuilders.*;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.positivity.controllers.BlogPostController;
import com.positivity.controllers.UserController;

public class BlogPostControllerTest {
	
	
	@Test
	public void testHomePage() throws Exception {
		
		BlogPostController controller = new BlogPostController();
		MockMvc mockMvc = standaloneSetup(controller).build();
		mockMvc.perform(get("/")).andExpect(view().name("home"));
		
	}
	

}
